``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.22000
Intel Core i5-8300H CPU 2.30GHz (Coffee Lake), 1 CPU, 8 logical and 4 physical cores
.NET SDK=6.0.101
  [Host]     : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT
  Job-ROYBJX : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT

InvocationCount=1  MaxIterationCount=5  MinIterationCount=4  
UnrollFactor=1  

```
|    Method |    Rows |     Mean |    Error |  StdDev |      Min |      Max |       Q1 |       Q3 | Iterations | Rank |
|---------- |-------- |---------:|---------:|--------:|---------:|---------:|---------:|---------:|-----------:|-----:|
| **RunExport** |  **500000** |  **28.18 s** | **22.919 s** | **5.952 s** |  **23.41 s** |  **35.81 s** |  **24.11 s** |  **33.46 s** |      **5.000** |    **1** |
| **RunExport** | **1000000** |  **84.02 s** |  **8.328 s** | **2.163 s** |  **80.68 s** |  **85.67 s** |  **82.97 s** |  **85.44 s** |      **5.000** |    **2** |
| **RunExport** | **1500000** | **146.42 s** | **19.738 s** | **5.126 s** | **139.16 s** | **153.14 s** | **145.34 s** | **148.79 s** |      **5.000** |    **3** |
| **RunExport** | **2000000** | **216.51 s** | **12.246 s** | **3.180 s** | **212.57 s** | **220.45 s** | **214.74 s** | **218.92 s** |      **5.000** |    **4** |
