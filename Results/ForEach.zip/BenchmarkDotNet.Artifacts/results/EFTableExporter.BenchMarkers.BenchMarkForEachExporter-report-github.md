``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.22000
Intel Core i5-8300H CPU 2.30GHz (Coffee Lake), 1 CPU, 8 logical and 4 physical cores
.NET SDK=6.0.101
  [Host]     : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT
  Job-FWDKWS : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT

InvocationCount=1  MaxIterationCount=5  MinIterationCount=4  
UnrollFactor=1  

```
|    Method |    Rows |    Mean |    Error |  StdDev |     Min |     Max |      Q1 |      Q3 | Iterations | Rank |
|---------- |-------- |--------:|---------:|--------:|--------:|--------:|--------:|--------:|-----------:|-----:|
| **RunExport** |  **500000** | **21.07 s** |  **1.290 s** | **0.200 s** | **20.82 s** | **21.26 s** | **20.97 s** | **21.22 s** |      **4.000** |    **1** |
| **RunExport** | **1000000** | **44.76 s** | **15.708 s** | **4.079 s** | **40.89 s** | **49.20 s** | **41.69 s** | **49.12 s** |      **5.000** |    **2** |
| **RunExport** | **1500000** | **69.80 s** | **12.550 s** | **3.259 s** | **64.20 s** | **72.28 s** | **70.04 s** | **71.86 s** |      **5.000** |    **3** |
| **RunExport** | **2000000** | **91.29 s** | **10.599 s** | **1.640 s** | **89.06 s** | **92.74 s** | **90.58 s** | **92.39 s** |      **4.000** |    **4** |
