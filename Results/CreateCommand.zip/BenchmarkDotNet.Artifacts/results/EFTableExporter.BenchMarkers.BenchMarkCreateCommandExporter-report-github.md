``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.22000
Intel Core i5-8300H CPU 2.30GHz (Coffee Lake), 1 CPU, 8 logical and 4 physical cores
.NET SDK=6.0.101
  [Host]     : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT
  Job-FLRCMC : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT

InvocationCount=1  MaxIterationCount=5  MinIterationCount=4  
UnrollFactor=1  

```
|    Method |    Rows |    Mean |    Error |  StdDev |     Min |     Max |      Q1 |      Q3 | Iterations | Rank |
|---------- |-------- |--------:|---------:|--------:|--------:|--------:|--------:|--------:|-----------:|-----:|
| **RunExport** |  **500000** | **16.66 s** |  **2.126 s** | **0.552 s** | **16.15 s** | **17.51 s** | **16.34 s** | **16.92 s** |      **5.000** |    **1** |
| **RunExport** | **1000000** | **31.97 s** | **12.965 s** | **2.006 s** | **29.93 s** | **34.72 s** | **31.03 s** | **32.56 s** |      **4.000** |    **2** |
| **RunExport** | **1500000** | **51.44 s** |  **2.407 s** | **0.625 s** | **50.76 s** | **52.39 s** | **51.03 s** | **51.60 s** |      **5.000** |    **3** |
| **RunExport** | **2000000** | **69.26 s** | **21.375 s** | **5.551 s** | **60.12 s** | **74.12 s** | **68.15 s** | **72.29 s** |      **5.000** |    **4** |
